OpenBeacon Windows 7 driver installation instructions

Open Device Manager (Click Start, and then click Control Panel.

Click Hardware and Sound.

Click Device Manager.)
Find "OpenBeacon", right-click, select "Update Driver Software..."
Select "Browse my computer for driver software"
Click "Browse...", select the "OpenBeacon Driver" folder which you unzipped, click "OK", click "Next"
"Windows can't verify the publisher of this driver software", select "Install this driver software anyway"
Click "Close"